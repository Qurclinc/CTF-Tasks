import express, { response } from "express";
import bcrypt from "bcrypt";
import path from "path";
import { fileURLToPath } from "url";
import cookieParser from "cookie-parser";
import jwt from "jsonwebtoken";
import { promises as fs } from "fs";
import rateLimit from "express-rate-limit";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename)
const SECRET_KEY = "supersecure"

const app = express();
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(express.static(__dirname + "/public"));
app.use(cookieParser());

// Will add database in future, for now, this should suffice.
const users = []

const limiter = rateLimit({
    windowMs: 10 * 1000,
    max: 1,
    message: "Only 1 request every 10 seconds."
})

// for admin ofc
async function initAdmin() {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash("donttrytocrackitsuseless", salt);
    users.push({username: "admin", password: hashedPassword})
}
initAdmin();

async function isAdmin(req, res, next) {
    if (req.user !== "admin") return res.status(403).send("<h1> You are not admin. </h1>")
    next();
}

async function auth(req, res, next) {
    const token = req.cookies.token;
    if (!token) return res.redirect("/login");
    try {
        const user = await jwt.verify(token, SECRET_KEY);
        if (!users.some(u => u.username === user.username)) {
            return res.status(400).send("<h1> Please Login Again. </h1> ");
        }
        req.user = user.username;
    } catch (err) {
        console.log(err);
        return res.redirect("/login");
    }
    next();
}

async function addPost(content, heading, props) {
    try {
        const files = await fs.readdir("posts");
        const idx = files.length + 1;
        await fs.mkdir(`posts/${idx}`)
        await fs.writeFile(`posts/${idx}/content.ejs`, content)
        await fs.writeFile(`posts/${idx}/properties.json`, JSON.stringify({id: idx, author: "admin", title: heading, content: content.substring(0, 20) + "...", visibility: props.visibility}))
        return [true, ""];
    } catch (err) {
        return [false, err];
    }
}

app.get("/", (req, res) => {
    res.render("index.ejs");
});

app.get("/register", (req, res) => {
    res.render("register.ejs");
})

app.post("/register", async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = users.find(user => user.username === username);
        if (user) {
            return res.json({ response: "User already exists." });
        } else {
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(password, salt);
            users.push({ username, password: hashedPassword })
            return res.json({ response: "Successfully registered. Proceed to login." })
        }
    } catch (err) {
        console.log(err);
        return res.json({ response: "Internal Server Error."})
    }
})

app.get("/login", (req, res) => {
    res.render("login.ejs")
})

app.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = users.find(user => user.username === username);
        if (!user) {
            return res.status(401).send("<h1>Invalid credentials.</h1>")
        }
        const check = await bcrypt.compare(password, user.password);
        if (!check) {
            return res.status(401).send("<h1>Invalid credentials.</h1>")
        }
        const token = jwt.sign( { username }, SECRET_KEY, { expiresIn: "1h" } )
        res.cookie("token", token, { httpOnly: true, maxAge: 3600000 })
        res.redirect("/dashboard");
    } catch (err) {
        console.log(err);
        return res.status(500).send({response: "Internal Server Error."})
    }
})

app.get("/dashboard", auth, async (req, res) => {
    const user = req.user;
    const posts = []
    try {
        const files = await fs.readdir("posts", {withFileTypes: true});
        for (const file of files) {
            if (file.isDirectory()) {
                const contents = await fs.readFile(`posts/${file.name}/properties.json`);
                const jsonContents =  JSON.parse(contents);
                posts.push(jsonContents);
            }
        }
        res.render("dashboard.ejs", { user, posts});
    } catch (err) {
        console.log(err);
        res.send("<h1>Error</h1>");
    }
})

app.get("/addPost", auth, isAdmin, (req, res) => {
    try {
        return res.render("addPost.ejs");
    } catch (err) {
        return res.status(500).json( {response: "Internal server error. "})
    }
})

app.post("/addPost", auth, isAdmin, async (req, res) => {
    try {
        const user = "admin";
        const { content, title, visibility} = req.body;
        const [result, msg] = await addPost(content, title, visibility);
        if (result) {
            return res.status(200).json({ response: "Added Post." })
        } else {
            return res.json({response: "Failed to add post.", error: msg})
        }
    } catch (err) {
        console.log(err);
        return res.status(500).json( {response: "Internal server error. "})
    }
})

app.get("/post", auth, async (req, res) => {
    try {
        const params = req.query;
        if (parseInt(params.id) != params.id) {
            return res.status(400).send("<h1> Bad Request </h1>")
        }
        const props = await fs.readFile(`posts/${params.id}/properties.json`)
        const jsonProps = JSON.parse(props);
        if (jsonProps.visibility === false) {
            return res.status(404).send("<h1> Admin does not want you to see this post. </h1>")
        }
        return res.render("post.ejs", { ...params, ...jsonProps })
    } catch (err) {
        console.log(err);
        return res.status(500).json({ response: "Internal Server Error." });
    }
})

app.get("/resetPassword", auth, async (req, res) => {
    const username = req.user;
    return res.render("resetPassword.ejs", { username })
})

app.post("/resetPassword", auth, async (req, res) => {
    const { username, newPassword } = req.body;
    const idx = users.findIndex(user => user.username === username);
    if (idx === -1) return res.status(404).send("User not found. ");
    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(newPassword, salt);
        users[idx] = { ...users[idx], password: hashedPassword }
        return res.send("Password reset successfully.")
    } catch (err) {
        console.log(err);
        return res.status(500).json({response: "Internal Server Error."})
    }
})

app.get("/modifyPost", auth, isAdmin, async (req, res) => {
    try {
        const dir = await fs.readdir("posts")
        const maxIdx = dir.length;
        const posts = []
        for (let index = 1; index <= maxIdx; index++) {
            try {
                const data = await fs.readFile(`posts/${index}/properties.json`);
                posts.push(JSON.parse(data));
            } catch (err) {
                console.log(err);
                continue;
            }
        }
        res.render("modifyPost.ejs", {posts});
    } catch (err) {
        console.log(err);
        return res.status(500).send("<h1> Internal Server Error </h1>")
    }
})

app.post("/modifyPost", limiter, auth, isAdmin, async (req, res) => {
    try {
        const { idx, visibility } = req.body;
        const props = await fs.readFile(`posts/${idx}/properties.json`)
        const jsonProps = JSON.parse(props) 
        jsonProps.visibility = visibility;
        await fs.writeFile(`posts/${idx}/properties.json`, JSON.stringify(jsonProps))
        return res.status(200).json({ success: true })
    } catch (err) {
        console.log(err);
        return res.status(500).json({ success: false })
    }
})

app.get("/logout", auth, (req, res) => {
    res.clearCookie("token");
    res.redirect("/login");
})

app.listen(3000, (err) => {
    console.log(err);
})


// TODO:
// Integrate Database.
